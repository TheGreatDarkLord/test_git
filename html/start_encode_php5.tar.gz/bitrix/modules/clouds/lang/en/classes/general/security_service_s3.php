<?
$MESS["CLO_SECSERV_S3_XML_PARSE_ERROR"] = "unrecognized service response (error ##errno#)";
$MESS["CLO_SECSERV_S3_XML_ERROR"] = "service error: #errmsg#";
?>