<?
$MESS["CLO_STORAGE_FILE_NAME"] = "Name";
$MESS["CLO_STORAGE_FILE_SIZE"] = "Size";
$MESS["CLO_STORAGE_FILE_DELETE"] = "Delete";
$MESS["CLO_STORAGE_FILE_DELETE_CONF"] = "Do you want to delete the file irreversibly?";
$MESS["CLO_STORAGE_FILE_SHOW_DIR_SIZE"] = "Folder size";
$MESS["CLO_STORAGE_FILE_SHOW_DIR_SIZE_TITLE"] = "Show folder size, including nested folders";
$MESS["CLO_STORAGE_FILE_LIST_ERROR"] = "Error getting file list.";
$MESS["CLO_STORAGE_FILE_UPLOAD_ERROR"] = "File upload error:";
$MESS["CLO_STORAGE_FILE_EXISTS_ERROR"] = "A file with this name already exists in the cloud storage.";
$MESS["CLO_STORAGE_FILE_OPEN_ERROR"] = "Error opening the file for reading.";
$MESS["CLO_STORAGE_FILE_UNKNOWN_ERROR"] = "Unknown error [#CODE#].";
$MESS["CLO_STORAGE_FILE_UPLOAD_IN_PROGRESS"] = "Now uploading file:";
$MESS["CLO_STORAGE_FILE_UPLOAD_DONE"] = "File uploaded:";
$MESS["CLO_STORAGE_FILE_UPLOAD_PROGRESS"] = "
Uploaded: <b>#bytes#</b> of <b>#file_size#</b>.
";
$MESS["CLO_STORAGE_FILE_STOP"] = "Stop";
$MESS["CLO_STORAGE_FILE_UPLOAD"] = "New file";
$MESS["CLO_STORAGE_FILE_UPLOAD_TITLE"] = "Upload new file to cloud storage.";
$MESS["CLO_STORAGE_FILE_UPLOAD_BTN"] = "Upload";
$MESS["CLO_STORAGE_FILE_CANCEL_BTN"] = "Cancel";
$MESS["CLO_STORAGE_FILE_UPLOAD_INPUT"] = "File";
$MESS["CLO_STORAGE_FILE_PATH_INPUT"] = "Path";
?>