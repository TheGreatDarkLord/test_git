<?
$MESS["OP_NAME_CLOUDS_BROWSE"] = "Browse cloud storages";
$MESS["OP_NAME_CLOUDS_UPLOAD"] = "Upload new files and download existing files";
$MESS["OP_NAME_CLOUDS_CONFIG"] = "Edit cloud storage connection parameters";
?>