<?
$MESS["CLO_INSTALL"] = "Cloud Storages module installation.";
?>