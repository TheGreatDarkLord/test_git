<?
$MESS["BCL_BACKUP_AI_TITLE"] = "Backup";
$MESS["BCL_BACKUP_AI_USAGE_TOTAL"] = "Total:";
$MESS["BCL_BACKUP_AI_USAGE_AVAIL"] = "Available:";
$MESS["BCL_BACKUP_AI_NO_FILES"] = "There are no backups yet.";
$MESS["BCL_BACKUP_AI_LAST_TIME"] = "Last created";
$MESS["BCL_BACKUP_AI_DO_BACKUP_STRONGLY"] = "Create backup now";
$MESS["BCL_BACKUP_AI_DO_BACKUP"] = "Create backup";
?>