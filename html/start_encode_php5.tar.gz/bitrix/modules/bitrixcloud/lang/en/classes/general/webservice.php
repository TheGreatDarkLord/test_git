<?
$MESS["BCL_CDN_WS_SERVER"] = "Error getting parameters from server (code: #STATUS#).";
$MESS["BCL_CDN_WS_XML_PARSE"] = "Error parsing XML config file (code: #CODE#).";
$MESS["BCL_CDN_WS_LICENSE_NOT_FOUND"] = "Your license is invalid.";
$MESS["BCL_CDN_WS_LICENSE_EXPIRE"] = "Your license has expired.";
$MESS["BCL_CDN_WS_QUOTA_EXCEEDED"] = "Traffic quota exceeded.";
$MESS["BCL_CDN_WS_LICENSE_DEMO"] = "Service is unavailable for this license type.";
$MESS["BCL_CDN_WS_LICENSE_NOT_ACTIVE"] = "License is inactive.";
$MESS["BCL_CDN_WS_DOMAIN_NOT_REACHABLE"] = "The specified URL cannot be accessed from cloud.";
$MESS["BCL_CDN_WS_NOT_POWERED_BY_BITRIX_CMS"] = "The specified website is not powered by Bitrix Site Manager.";
$MESS["BCL_CDN_WS_CMS_LICENSE_NOT_FOUND"] = "This website's license is invalid.";
$MESS["BCL_CDN_WS_WRONG_DOMAIN_SPECIFIED"] = "The specified website is using a different license key.";
?>