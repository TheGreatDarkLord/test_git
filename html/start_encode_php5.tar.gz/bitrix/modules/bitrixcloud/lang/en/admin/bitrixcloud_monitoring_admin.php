<?
$MESS["BCL_MONITORING_DOMAIN"] = "Domain";
$MESS["BCL_MONITORING_LICENSE"] = "License will expire in:";
$MESS["BCL_MONITORING_NO_DOMAINS_CONFIGURED"] = "There are no domains configured for at least one website.";
$MESS["BCL_MONITORING_DELETE"] = "Delete";
$MESS["BCL_MONITORING_EDIT"] = "Edit";
$MESS["BCL_MONITORING_DOMAIN_REGISTRATION"] = "The domain will expire in:";
$MESS["BCL_MONITORING_SSL"] = "SSL certificate will expire in:";
$MESS["BCL_MONITORING_RESPONSE_TIME"] = "Website response";
$MESS["BCL_MONITORING_NO_DATA"] = "no data yet";
$MESS["BCL_MONITORING_NO_DATA_AVAILABLE"] = "unavailable";
$MESS["BCL_MONITORING_PERIOD"] = "Monitor time:";
$MESS["BCL_MONITORING_FAILED_PERIOD"] = "Downtime:";
$MESS["BCL_MONITORING_DOMAIN_REGISTRATION_NOTE"] = "For some top-level domains the domain expiration time cannot be resolved because not all registrars provide this information.";
$MESS["BCL_MONITORING_TITLE"] = "Cloud Inspector";
$MESS["BCL_MONITORING_START"] = "Add site to Inspector";
$MESS["BCL_MONITORING_DELETE_CONF"] = "Are you sure you want to stop Cloud Inspector on this domain?";
$MESS["BCL_MONITORING_RESULT"] = "Inspector results";
?>