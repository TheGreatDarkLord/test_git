<?
$MESS["BCLMMD_PARAM_HTTP_RESPONSE_TIME"] = "Website response";
$MESS["BCLMMD_PARAM_FAILED_PERIOD"] = "Downtime";
$MESS["BCLMMD_PARAM_MONITORING_PERIOD"] = "Date range";
$MESS["BCLMMD_PARAM_DOMAIN_REGISTRATION"] = "The domain will expire in";
$MESS["BCLMMD_PARAM_LICENSE"] = "License will expire in";
$MESS["BCLMMD_PARAM_MONITORING_SSL"] = "SSL certificate will expire in";
$MESS["BCLMMD_EDIT"] = "Edit site";
$MESS["BCLMMD_DELETE"] = "Delete site";
$MESS["BCLMMD_DELETE_CONFIRM"] = "Are you sure you want to remove the website from the list?";
$MESS["BCLMMD_BUTT_CANCEL"] = "Cancel";
$MESS["BCLMMD_BUTT_OK"] = "Remove";
$MESS["BCLMMD_TITLE"] = "Cloud Inspector";
$MESS["BCLMMD_NO_DATA"] = "No data.";
?>