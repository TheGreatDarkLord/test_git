<?
$MESS["BCLMMSL_MONITORING_HTTP_RESPONSE_TIME"] = "Website response";
$MESS["BCLMMSL_MONITORING_FAILED_PERIOD"] = "Downtime";
$MESS["BCLMMSL_MONITORING_MONITORING_PERIOD"] = "Date range";
$MESS["BCLMMSL_MONITORING_DOMAIN_REGISTRATION"] = "The domain will expire in";
$MESS["BCLMMSL_MONITORING_LICENSE"] = "License will expire in";
$MESS["BCLMMSL_MONITORING_MONITORING_SSL"] = "SSL certificate will expire in";
$MESS["BCLMMSL_MONITORING_TITLE"] = "Website Inspector";
$MESS["BCLMMSL_MONITORING_NO_PROBS"] = "There are currently no problems with your websites.";
$MESS["BCLMMSL_MONITORING_BUT_DETAIL"] = "Details";
$MESS["BCLMMSL_MONITORING_MONTH_LOST"] = "Monthly loss";
$MESS["BCLMMSL_NO_DOMAINS"] = "No domains configured";
$MESS["BCLMMSL_NO_SITES"] = "There are currently no websites.<br>Click (+) to add one.";
$MESS["BCLMMSL_NO_SITES_TITLE"] = "Message";
$MESS["BCLMMSL_NO_DATA"] = "no data";
$MESS["BCLMMSL_TITLE"] = "Cloud Inspector";
?>