<?
$MESS["BCLMME_TITLE"] = "Inspector parameters";
$MESS["BCLMME_DOMAIN_TITLE"] = "Domain";
$MESS["BCLMME_HTTP_RESPONSE_TIME_TITLE"] = "Website response";
$MESS["BCLMME_TEST_DOMAIN_REGISTRATION_TITLE"] = "Domain registered on";
$MESS["BCLMME_TEST_LICENSE_TITLE"] = "Bitrix license will expire on";
$MESS["BCLMME_IS_HTTPS_TITLE"] = "Use HTTPS";
$MESS["BCLMME_LANG_TITLE"] = "Alert language";
$MESS["BCLMME_EMAILS_TITLE"] = "Send alerts to e-mail";
$MESS["BCLMME_HEAD"] = "Edit parameters";
?>