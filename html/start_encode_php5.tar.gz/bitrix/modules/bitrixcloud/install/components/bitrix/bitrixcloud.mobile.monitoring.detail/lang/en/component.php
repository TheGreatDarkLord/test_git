<?
$MESS["BCLMMD_BC_NOT_INSTALLED"] = "The Bitrix Cloud module is not installed.";
$MESS["BCLMMD_MA_NOT_INSTALLED"] = "The Mobile Builder module is not installed.";
$MESS["BCLMMD_NO_DATA"] = "No data.";
$MESS["BCLMMD_MONITORING_NO_DATA"] = "no data yet";
$MESS["BCLMMD_MONITORING_NO_DATA_AVAILABLE"] = "unavailable";
$MESS["BCLMMD_ACCESS_DENIED"] = "Access denied";
?>