<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/bitrixcloud/admin/bitrixcloud_cdn.php");
?>