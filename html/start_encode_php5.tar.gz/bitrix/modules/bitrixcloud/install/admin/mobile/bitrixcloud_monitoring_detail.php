<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/bitrixcloud/admin/mobile/monitoring_detail.php");
?>