<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/bitrixcloud/admin/bitrixcloud_monitoring_admin.php");
?>