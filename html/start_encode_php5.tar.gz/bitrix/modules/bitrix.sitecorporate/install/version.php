<?
$arModuleVersion = array(
	"VERSION" => "15.0.0",
	"VERSION_DATE" => "2015-01-22 9:00:00"
);
?>