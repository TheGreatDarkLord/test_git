<?
$MESS["CR_PRICE"] = "Price";
?>