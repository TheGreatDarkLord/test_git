<?
$MESS["SUPPORT_FAQ_EL_GROUP_SETTINGS"] = "Component Settings";
$MESS["SUPPORT_FAQ_EL_SETTING_IBTYPES"] = "Information Block Types";
$MESS["SUPPORT_FAQ_EL_SETTING_IBLIST"] = "Information Blocks";
$MESS["CP_BSFEL_CACHE_GROUPS"] = "Regard Access Permission";
?>