<?
$MESS["T_IBLOCK_DESC_CR_LIST"] = "Special Offer";
$MESS["T_IBLOCK_DESC_CR_DESC"] = "Shows one special offer.";
$MESS["T_IBLOCK_DESC_CATALOG"] = "Catalog";
?>