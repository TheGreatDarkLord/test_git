<?
$MESS["CFST_THEME_GRAY"] = "Grey";
?>