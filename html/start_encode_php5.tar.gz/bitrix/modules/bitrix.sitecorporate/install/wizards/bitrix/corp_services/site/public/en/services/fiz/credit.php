<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Personal Loans");
?>

	<p>A Bank Personal Loan is a fast and convenient way to get the things you want.<p>
	<p>Get more freedom with a Personal Loan.<p>
	<h2>Bank Rate Personal Loan</h2> 
		
	<ul>
		<li>Loans range from $900 to $300,000</li> 
		<li>Loan terms of 2 to 5 years</li>
		<li>Fixed rates ranging from 10.49% APR to 25.49% APR.</li>
		<li>Loan Approval Fee: $200 covers application and loan establishment costs.</li>
	</ul>
	 
	<h2>To be eligible to apply for a J&V Personal Loan, you need to be:</h2> 
	<ul>
		<li>A permanent USA resident.</li> 
		<li>Over the age of 18 years.</li> 
		<li>Minimum employment: Employed a minimum of 2 years with a minimum of 1 year in your current organization.</li> 
		<li>Minimum Annual Income: $40,000 p.a.</li> 
	</ul> 	
 
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>