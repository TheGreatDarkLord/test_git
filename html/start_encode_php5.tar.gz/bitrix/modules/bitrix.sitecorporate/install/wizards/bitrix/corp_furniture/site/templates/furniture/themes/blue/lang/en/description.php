<?
$MESS["CFST_THEME_BLUE"] = "Blue";
?>