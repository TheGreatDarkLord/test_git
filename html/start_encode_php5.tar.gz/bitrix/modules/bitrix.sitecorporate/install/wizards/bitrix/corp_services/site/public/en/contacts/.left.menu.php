<?
$aMenuLinks = Array(
	Array(
		"Contacts", 
		"index.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Bank details", 
		"requisites.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Feedback", 
		"feedback.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>