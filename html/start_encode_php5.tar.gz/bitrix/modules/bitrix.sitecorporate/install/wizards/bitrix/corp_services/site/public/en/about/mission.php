<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Mission and Purpose");
?>
	    <h2>Mission</h2> 
	    <p>By reacting to our client' needs, we can offer them the best financial solutions. In this way, we can continuously increase our company's value and serve as a positive force in society.</p> 
	    <h2>Purposes</h2> 
	    <p>Our goal - to provide each client with the full range of modern banking products and services using the latest achievements and innovations in financial technology. Our aim is to be the service leaders of our industry.</p> 
	     
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>