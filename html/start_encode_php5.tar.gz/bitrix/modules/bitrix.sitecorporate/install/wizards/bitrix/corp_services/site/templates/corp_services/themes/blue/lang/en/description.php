<?
$MESS["CPST_BLUE"] = "Blue";
?>