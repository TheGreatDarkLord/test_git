<?
$aMenuLinks = Array(
	Array(
		"Trade Services", 
		"trade.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Card Solutions", 
		"card.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Merchant Services", 
		"merchant.php", 
		Array(), 
		Array(), 
		"" 
	),
);
?>