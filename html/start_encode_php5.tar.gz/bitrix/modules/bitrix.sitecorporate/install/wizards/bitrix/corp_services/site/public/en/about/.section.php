<?
$sSectionName = "About J&V";
$arDirProperties = Array(

);
?>