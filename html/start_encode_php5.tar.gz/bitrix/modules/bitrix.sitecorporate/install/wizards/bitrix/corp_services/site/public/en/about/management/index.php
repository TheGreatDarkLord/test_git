<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Governance");
?>
<h2>Management Board</h2>

<p>
  <table class="data-table" cellspacing="0">
    <tbody>
      <tr><th></th><th>Position</th><th>Background</th></tr>
    
      <tr class="alt-row"><td>Joel Ainsworth </td><td>Head of Private & Business Clients </td><td>B.A. in Language and Economics</td></tr>
    
      <tr><td>Olivia Acres </td><td>Chief Operating Officer </td><td>Sc. in Business Administration </td></tr>
    
      <tr class="alt-row"><td>Naomi Bessie </td><td>Chief Financial Officer </td><td>M. Sc. in Business Administration and Economics </td></tr>
    
      <tr><td>Serge Clemons </td><td>CFO </td><td>B. Sc. in Business Administration </td></tr>
    
      <tr class="alt-row"><td>Morgan Atkinson </td><td>President and CEO </td><td>M.Sc. in Business Administration and Economics </td></tr>
    </tbody>
  </table>
</p>

<h2>Group Executive Committee</h2>

<p>
  <table class="data-table" cellspacing="0">
    <tbody>
      <tr><th></th><th>Position</th><th>Background</th></tr>
    
      <tr class="alt-row"><td>Ryan Appleby </td><td>Head of Private Wealth Management </td><td>Psychology and Pedagogy and B. Sc. (Econ.) </td></tr>
    
      <tr><td>Andrew Allerton </td><td>Head of Retail </td><td>M. Sc. in Business Administration and Economics </td></tr>
    
      <tr class="alt-row"><td>Daisy Allenby </td><td>Chief Risk Officer </td><td>M.Sc. in Business Administration and Economics </td></tr>
    
      <tr><td>Michael Alleine </td><td>Head of Global Transaction Banking </td><td>M. Sc. in Business Administration and Economics </td></tr>
    
    </tbody>
  </table>
</p>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>