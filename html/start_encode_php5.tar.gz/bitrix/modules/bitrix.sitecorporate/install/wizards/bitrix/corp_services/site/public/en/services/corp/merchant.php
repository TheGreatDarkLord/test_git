<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Merchant Services");
?>

			<p>The Merchant Services program enables your company to accept credit card payments from your clients for goods and services sold.</p> 
			 
			<h2>J&V is uniquely positioned to provide you the very latest payment industry technology, products, and services, including:</h2> 
			 
			<ul><li>Gift, Credit and Debet cards; </li> 
			<li>Equipment leasing;</li> 
			<li>24-hour/7-days a week customer support and free staff telephone training;</li> 
			<li>Internet and phone payments;</li> 
			<li>Access your reporting online;</li> 
			<li>Chargeback and retrieval service;</li> 
			</ul> 
			 
			 <p>We are eager to help you solve your payment processing challenges.</p>													

 
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>