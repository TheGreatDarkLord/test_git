<?
$MESS["CPST_GRAY"] = "Grey";
?>