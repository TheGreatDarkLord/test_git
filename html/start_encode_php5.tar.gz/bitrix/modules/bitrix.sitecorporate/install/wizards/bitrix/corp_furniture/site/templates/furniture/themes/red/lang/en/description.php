<?
$MESS["CFST_THEME_RED"] = "Red";
?>