<?
$MESS["CFST_TEMPLATE_NAME"] = "Fixed";
$MESS["CFST_TEMPLATE_DESC"] = "Light and clear fixed-width template.";
?>