<?
$MESS ['MENU_TREE_NAME'] = "Left menu";
$MESS ['MENU_TREE_DESC'] = "Left menu";
?>