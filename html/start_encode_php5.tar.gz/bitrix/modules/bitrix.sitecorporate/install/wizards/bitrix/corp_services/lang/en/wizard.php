<?
$MESS["wiz_structure_data"] = "Install Corporate Website Demo Data";
$MESS["wiz_restructure_data"] = "Reinstall Corporate Website Demo Data";
$MESS["WIZ_COMPANY_LOGO"] = "Logo (recommended size: 190 x 25)";
$MESS["WIZ_SITE_BANNER"] = "Banner (recommended size: 580 x 175)";
$MESS["WIZ_BANNER_TEXT"] = "Banner Text";
$MESS["WIZ_BANNER_TEXT_DEFAULT"] = "<big>Making Plans For Life?</big>
<span> Affordable Mortgage! </span>
<small>Learn more about loans</small>";
$MESS["WIZ_COMPANY_SLOGAN"] = "Company's Slogan";
$MESS["WIZ_COMPANY_SLOGAN_DEF"] = "Slogan Placeholder";
$MESS["WIZ_COMPANY_COPY"] = "Copyrights";
$MESS["WIZ_COMPANY_COPY_DEF"] = "<p>&copy; 2001-2014 Company name</p>
<p>Address</p>";
$MESS["wiz_site_name"] = "Corporate Website";
$MESS["wiz_site_desc"] = "We are a cutting edge high-tech bank blending the new technology and the righteous banking traditions together.";
$MESS["wiz_keywords"] = "bank, loans, credit, mortgage";
$MESS["wiz_meta_data"] = "Metadata:";
$MESS["wiz_meta_description"] = "Site Description:";
$MESS["wiz_meta_keywords"] = "Keywords:";
?>