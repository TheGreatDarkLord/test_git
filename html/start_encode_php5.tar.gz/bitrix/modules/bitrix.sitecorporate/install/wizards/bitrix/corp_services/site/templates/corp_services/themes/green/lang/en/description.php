<?
$MESS["CPST_GREEN"] = "Green";
?>